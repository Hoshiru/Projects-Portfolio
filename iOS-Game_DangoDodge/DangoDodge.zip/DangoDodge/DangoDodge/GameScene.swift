//
//  GameScene.swift
//  DangoDodge
//
//  Created by Jared Hayes on 3/17/16.
//  Copyright (c) 2016 Jared Hayes. All rights reserved.
//

import SpriteKit

class GameScene: SKScene, SKPhysicsContactDelegate{
    
    var hero:Hero!
    var touchLocation = CGFloat()
    var gameOver = false
    var badGuys:[Enemies] = []
    var endOfScreenTop = CGFloat()
    var endOfScreenBottom = CGFloat()
    var score = 0
    var scoreLabel = SKLabelNode()
    var refresh = SKSpriteNode(imageNamed: "refresh")
    let explode = SKSpriteNode(imageNamed: "explosion")
    var timer = NSTimer()
    var countDownText = SKLabelNode(text: "5")
    var countDown = 5
    
    enum ColliderType:UInt32 {
        case Hero = 1
        case Enemies = 2
        case PowerUp = 3
        case Blast = 4
    }

    override func didMoveToView(view: SKView) {
        self.physicsWorld.contactDelegate = self
        endOfScreenBottom = 0.0
        endOfScreenTop = self.size.height
        addBG()
        addHero()
        addBadGuys()
        scoreLabel = SKLabelNode(text: "0")
        scoreLabel.position.y = self.size.height/4
        scoreLabel.position.x = self.size.width/2
        countDownText.position.y = self.size.height/2
        countDownText.position.x = self.size.width/2
        refresh.position.y = self.size.height/2
        refresh.position.x = self.size.width/2
        addChild(scoreLabel)
        addChild(refresh)
        addChild(explode)
        addChild(countDownText)
        countDownText.hidden = true
        refresh.name = "refresh"
        refresh.hidden = true
        explode.hidden = true
        self.runAction(SKAction.playSoundFileNamed("slowmotion.mp3", waitForCompletion: false))
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        if contact.bodyA.contactTestBitMask == ColliderType.Enemies.rawValue && contact.bodyB.contactTestBitMask == ColliderType.Hero.rawValue {
            
            hero.emit = true
            gameOver = true
            refresh.hidden = false
            explode.hidden = false
            
            explode.position = hero.guy.position
            self.runAction(SKAction.playSoundFileNamed("Sound Explode.mp3", waitForCompletion: false))
        }
        else if contact.bodyA.contactTestBitMask == ColliderType.Enemies.rawValue && contact.bodyB.contactTestBitMask == ColliderType.PowerUp.rawValue {
            contact.bodyB.node?.hidden = true
            score = score + 50
            scoreLabel.text = String(score)
            self.runAction(SKAction.playSoundFileNamed("sound bite.mp3", waitForCompletion: false))
        }
        
    }
    
    func reloadGame() {
        countDownText.hidden = false
        explode.hidden = true
        hero.guy.position.y = self.size.height/5
        hero.guy.position.x = self.size.width/2
        refresh.hidden = true
        score = 0
        scoreLabel.text = "0"
        for badGuy in badGuys {
            resetBadGuy(badGuy.guy, xPos: badGuy.xPos)
            badGuy.guy.hidden = false
        }
        timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("updateTimer"), userInfo: nil, repeats: true)
    }
    
    func updateTimer() {
        if countDown > 0 {
            countDownText.hidden = false
            countDown--
            countDownText.text = String(countDown)
        } else {
            countDown = 5
            countDownText.text = String(countDown)
            countDownText.hidden = true
            gameOver = false
            timer.invalidate()
        }
    }
    
    func addBG() {
        let bgTexture = SKTexture(imageNamed: "bg")
        let bg = SKSpriteNode(texture: bgTexture)
        bg.anchorPoint = CGPointMake(0.0, 0.0)
        addChild(bg)
    }
    
    func addHero() {
        let dango = SKSpriteNode(imageNamed: "Dango")
        dango.anchorPoint = CGPointMake(0.5, 0.5)
        dango.position = CGPointMake(self.size.width/2, self.size.height/5)
        dango.physicsBody = SKPhysicsBody(circleOfRadius: dango.size.width/2)
        dango.physicsBody!.affectedByGravity = false
        dango.physicsBody!.categoryBitMask = ColliderType.Hero.rawValue
        dango.physicsBody!.contactTestBitMask = ColliderType.Enemies.rawValue
        dango.physicsBody!.collisionBitMask = ColliderType.Enemies.rawValue
        let heroParticles = SKEmitterNode()
        heroParticles.hidden = true
        hero = Hero(guy: dango, particles: heroParticles)
        dango.addChild(heroParticles)
        addChild(dango)
        hero.breathe()
    }
    
    func addBadGuys() {
        addBadGuy(named: "bomb", speed: -6, xPos: CGFloat(self.size.width/10), yPos:CGFloat(endOfScreenTop))
        addBadGuy(named: "bomb", speed: -4.5, xPos: CGFloat(self.size.width/4), yPos:CGFloat(endOfScreenTop))
        addBadGuy(named: "bomb", speed: -5.5, xPos: CGFloat(self.size.width/2), yPos:CGFloat(endOfScreenTop))
        addBadGuy(named: "bomb", speed: -5, xPos: CGFloat(self.size.width*0.75), yPos:CGFloat(endOfScreenTop))
        addBadGuy(named: "bomb", speed: -5, xPos: CGFloat(self.size.width*0.90), yPos:CGFloat(endOfScreenTop))
        addPowerUp(named: "treat", speed: -5.499999999, xPos: CGFloat(self.size.width/2), yPos:CGFloat(endOfScreenTop))
        addPowerUp(named: "blast", speed: -7, xPos: CGFloat(self.size.width*0.90), yPos:CGFloat(endOfScreenTop))
        
    }
    
    func addPowerUp(named named:String, speed:CGFloat, xPos:CGFloat, yPos:CGFloat) {
        let powerUpNode = SKSpriteNode(imageNamed: named)
        
        powerUpNode.physicsBody = SKPhysicsBody(circleOfRadius: powerUpNode.size.width/2)
        powerUpNode.physicsBody!.affectedByGravity = false
        powerUpNode.physicsBody!.categoryBitMask = ColliderType.PowerUp.rawValue
        powerUpNode.physicsBody!.contactTestBitMask = ColliderType.PowerUp.rawValue
        powerUpNode.physicsBody!.collisionBitMask = 0x0
        
        let badGuy = Enemies(speed: speed, guy: powerUpNode)
        badGuys.append(badGuy)
        resetBadGuy(powerUpNode, xPos: xPos)
        badGuy.xPos = powerUpNode.position.x
        badGuy.yPos = powerUpNode.position.y
        addChild(powerUpNode)
    }
    
    func addBadGuy(named named:String, speed:CGFloat, xPos:CGFloat, yPos:CGFloat) {
        let badGuyNode = SKSpriteNode(imageNamed: named)
        
        badGuyNode.physicsBody = SKPhysicsBody(circleOfRadius: badGuyNode.size.width/2)
        badGuyNode.physicsBody!.affectedByGravity = false
        badGuyNode.physicsBody!.categoryBitMask = ColliderType.Enemies.rawValue
        badGuyNode.physicsBody!.contactTestBitMask = ColliderType.Hero.rawValue
        badGuyNode.physicsBody!.collisionBitMask = ColliderType.Hero.rawValue
        
        let badGuy = Enemies(speed: speed, guy: badGuyNode)
        badGuys.append(badGuy)
        resetBadGuy(badGuyNode, xPos: xPos)
        badGuy.xPos = badGuyNode.position.x
        badGuy.yPos = badGuyNode.position.y
        addChild(badGuyNode)
    }
    
    func resetBadGuy(badGuyNode:SKSpriteNode, xPos:CGFloat) {
        badGuyNode.position.x = xPos
        badGuyNode.position.y = endOfScreenTop
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
       /* Called when a touch begins */
        for touch in touches {
            if !gameOver {
                touchLocation = (touch.locationInView(self.view!).x)
            }
            else {
                let location = touch.locationInNode(self)
                let sprites = nodesAtPoint(location)
                for sprite in sprites {
                    if let spriteNode = sprite as? SKSpriteNode {
                        if spriteNode.name != nil {
                            if spriteNode.name == "refresh" {
                                reloadGame()
                            }
                        }
                    }
                }
            }
        }
        
        //let moveAction = SKAction.moveByX(self.size.width/4, y: 0.0, duration: 0.5)
        let moveAction = SKAction.moveToX(touchLocation, duration: 0.5)
        moveAction.timingMode = SKActionTimingMode.EaseInEaseOut
        hero.guy.runAction(moveAction){
            // nothing yet
        }
        self.runAction(SKAction.playSoundFileNamed("Sound Woosh.mp3", waitForCompletion: false))
    }
    
    override func update(currentTime: CFTimeInterval) {
        if !gameOver {
            updateBadGuysPosition()
        }
        updateHeroEmitter()
    }
    
    func updateHeroEmitter() {
        if hero.emit && hero.emitFrameCount < hero.maxEmitFrameCount {
            hero.emitFrameCount++
            hero.particles.hidden = false
        } else {
            hero.emit = false
            hero.particles.hidden = true
            hero.emitFrameCount = 0
        }
        
    }
    
    
    func updateBadGuysPosition() {
        
        
        for badGuy in badGuys {
            let moveDown = SKAction.moveByX(0, y: badGuy.speed, duration: 1)
            if badGuy.guy.position.y <= endOfScreenBottom {
                badGuy.guy.position.y = endOfScreenTop
                badGuy.range += 0.1
                updateScore()
            }
            else {
                badGuy.guy.runAction(moveDown)
                badGuy.guy.position.x = CGFloat(Double(badGuy.guy.position.x) + sin(badGuy.angle) * badGuy.range)
                badGuy.angle += hero.speed
            }
        }
    }
    
    func updateScore() {
        score++
        scoreLabel.text = String(score)
    }
    
   
}
