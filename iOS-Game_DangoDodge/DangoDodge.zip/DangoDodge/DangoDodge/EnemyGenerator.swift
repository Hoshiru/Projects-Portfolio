//
//  EnemyGenerator.swift
//  DangoDodge
//
//  Created by Jared Hayes on 3/17/16.
//  Copyright © 2016 Jared Hayes. All rights reserved.
//

import Foundation
import SpriteKit

class EnemyGenerator {
    
    var generationTimer: NSTimer?
    var enemy = [Enemies]()
    var wallTrackers = [Enemies]()
    var guy: SKSpriteNode
    var size: CGFloat
    
    init(guy: SKSpriteNode, size: CGFloat) {
        self.guy = guy
        self.size = size
    }
    
    func startGeneratingWallsEvery(seconds: NSTimeInterval) {
        generationTimer = NSTimer.scheduledTimerWithTimeInterval(seconds, target: self, selector: "generateEnemies", userInfo: nil, repeats: true)
        
    }
    
    func stopGenerating() {
        generationTimer?.invalidate()
    }
    
    func generateEnemies() {
        var scale: CGFloat
        let rand = arc4random_uniform(2)
        if rand == 0 {
            scale = -1.0
        } else {
            scale = 1.0
        }
        
        let wall = Enemies(enemy: guy)
        wall.position.x = size.width/2 + wall.size.width/2
        wall.position.y = scale * (kMLGroundHeight/2 + wall.size.height/2)
        walls.append(wall)
        wallTrackers.append(wall)
        addChild(wall)
    }
    
    func stopWalls() {
        stopGenerating()
        for wall in walls {
            wall.stopMoving()
        }
    }
    
}
