//
//  PowerUp.swift
//  DangoDodge
//
//  Created by Jared Hayes on 3/17/16.
//  Copyright © 2016 Jared Hayes. All rights reserved.
//

import Foundation
import SpriteKit

class PowerUp {
    
    var speed:CGFloat = 0.0
    var guy:SKSpriteNode
    var currentFrame = 0
    var randomFrame = 0
    var moving = false
    var angle = 0.0
    var range = 2.0
    var xPos = CGFloat()
    var yPos = CGFloat()
    
    init(speed:CGFloat,guy:SKSpriteNode) {
        self.speed = speed
        self.guy = guy
    }
}