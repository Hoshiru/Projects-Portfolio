//
//  Hero.swift
//  DangoDodge
//
//  Created by Jared Hayes on 3/17/16.
//  Copyright © 2016 Jared Hayes. All rights reserved.
//

import Foundation
import SpriteKit

class Hero {
    var guy:SKSpriteNode
    var speed = 0.1
    var emit = false
    var emitFrameCount = 0
    var maxEmitFrameCount = 30
    var particles:SKEmitterNode
    
    init(guy:SKSpriteNode, particles:SKEmitterNode){
        self.guy = guy
        self.particles = particles
    }
    
    func breathe() {
        let breatheIn = SKAction.moveByX(0, y: 0.6, duration: 1)
        let breatheOut = SKAction.moveByX(0, y: -0.6, duration: 1)
        let breath = SKAction.sequence([breatheIn, breatheOut])
        guy.runAction(SKAction.repeatActionForever(breath))
    }
    
    func stopBreathe() {
        guy.removeAllActions()
    }
}